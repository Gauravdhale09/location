from django.db import models

# Create your models here.

class User(models.Model):
    name = models.CharField(max_length=100)
    department = models.CharField(max_length=4)
    ip_add = models.GenericIPAddressField()
    lati = models.FloatField(max_length=10)
    long = models.FloatField(max_length=10)

    def __str__(self):
        txt = f'Location : ({self.lati}, {self.long}) IP : {self.ip_add}'
        return txt
   
   
        
    

