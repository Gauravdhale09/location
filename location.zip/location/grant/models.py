from django.db import models

# Create your models here.

class User(models.Model):
    name = models.CharField(max_length=100)
    department = models.CharField(max_length=4)
    ip_address = models.GenericIPAddressField()
    latitude = models.FloatField(max_length=10)
    longitude = models.FloatField(max_length=10)
    time = models.CharField(max_length=100)
    def __str__(self):
        txt = f'Location : ({self.lati}, {self.long}) IP : {self.ip_add}'
        return txt
   
   
        
    

