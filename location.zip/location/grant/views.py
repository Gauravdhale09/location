from django.shortcuts import render
from .models import *
# Create your views here.

def index_page(request):
    if request.method == 'POST':
        lat = request.POST.get("latitude")
        long = request.POST.get("longitude")
        get_ip = ipaddress(request)
        data = request.POST
        name = data.get('user_name')
        department = data.get('branch')
        print(name, department, get_ip, lat, long)
        User.objects.create(
            name=name, 
            department=department,
            ip_add = get_ip,
            lati = lat,
            long = long,
        )
    return render(request, 'index.html')

def ipaddress(request):
    user_ip = request.META.get('HTTP_X_FORWARDED_FOR')
    if user_ip:
        ip = user_ip.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip
