from django.shortcuts import render
from .models import *
from django.utils import timezone
from datetime import datetime
# Create your views here.


def index_page(request):
    if request.method == 'POST':
        lat = request.POST.get("latitude")
        long = request.POST.get("longitude")
        if len(lat) > 0 and len(long) > 0:
            get_ip = ipaddress(request)
            data = request.POST
            name = data.get('user_name')
            department = data.get('branch')
            print(name, department, get_ip, lat, long)
            t = datetime.now().strftime("%d:%m:%y %H:%M:%S")
            User.objects.create(
                name=name, 
                department=department,
                ip_address = get_ip,
                latitude = lat,
                longitude = long,
                time=t
            )
            return render(request, 'thanks.html')
        else:
            return render(request, 'index.html', {'alert_message': 'Please turn on the location.'})
    
    return render(request, 'index.html')
def ipaddress(request):
    user_ip = request.META.get('HTTP_X_FORWARDED_FOR')
    if user_ip:
        ip = user_ip.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip
